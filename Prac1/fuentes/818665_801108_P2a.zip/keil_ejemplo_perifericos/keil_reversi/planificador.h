#ifndef PLANIFICADOR_H
#define PLANIFICADOR_H

#include <stdint.h>
#include "GPIO.h"
#include "cola_fifo.h"
#include "io_reserva.h"

// Inicializar cola de eventos
void inicializar_cola_eventos(void);









#endif // PLANIFICADOR_H

