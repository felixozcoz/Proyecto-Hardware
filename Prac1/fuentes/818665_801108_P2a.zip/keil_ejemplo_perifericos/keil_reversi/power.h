#ifndef POWER_H
#define POWER_H


void power_hal_wait(void);


#endif // POWER_H
