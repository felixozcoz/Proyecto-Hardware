                  
#include <LPC210x.H>                       /* LPC210x definitions */
#include "timer0.h"
#include "Power_management.h"
#include "boton_eint0.h"
#include "temporizador_drv.h"
#include "planificador.h"
#include "tests.h"
#include "GPIO.h"


// MAIN: Hello world
int main() {
	// inicialiar timer, interrumpe cada 10ms
	temporizador_drv_reloj(10, FIFO_encolar, EVENTO_HELLO_WORLD);
	
	// inicializar planificador
	inicializar_cola_eventos();
	
	while(1);
}


// MAIN: Test
//int main(){
//	// Test unitarios de perif�ricos
//	testGPIO();
//	testFIFO();
//	
//	while(1);
//}
