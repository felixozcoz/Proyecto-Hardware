// test.h
	
void testGPIO(void);
//void testT0(void);
//void testT1(void);
void testFIFO(void);
