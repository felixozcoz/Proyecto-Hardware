#define GPIO_button 12

// Leds
#define GPIO_LED_0 16
#define GPIO_LED_1 17
#define GPIO_LED_2 18
#define GPIO_LED_3 19
#define GPIO_LED_4 20
#define GPIO_LED_5 21
#define GPIO_LED_6 22
#define GPIO_LED_7 23

#define GPIO_LEDS_BITS 8

// Bits overflow
#define GPIO_OVERFLOW 31
#define GPIO_OVERFLOW_BITS 1

// Prueba "Hello World"
#define GPIO_HELLO_WORLD 0
#define GPIO_HELLO_WORLD_BITS 8
