// test.h	
	
#include <inttypes.h>
	
#define TEST_ALARMAS 0
#define TEST_BOTONES 1
#define TEST_FIFO 0
#define TEST_CONSUMO 0
#define DEMOSTRADOR 0
	
void testGPIO(void);
void testFIFO(void);
void test_botones(void);
void test_alarmas(void);
