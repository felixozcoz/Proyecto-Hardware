#ifndef	POWER_MANAGEMENT_H
#define POWER_MANAGEMENT_H


void PM_power_down (void); 

extern void Switch_to_PLL(void);


#endif // POWER_MANAGEMENT_H
